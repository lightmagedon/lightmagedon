@echo off
REM Lanzador del modpack LightMagedon
REM Ajusta la variable RAM a tu memoria disponible.
set RAM=8G
java -Xmx%RAM% -XX:+UseG1GC -Dfml.ignoreDisabledMods=true -jar fabric-server-launch.jar nogui
pause
