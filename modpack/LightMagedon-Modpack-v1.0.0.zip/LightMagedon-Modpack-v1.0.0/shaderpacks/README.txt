Shaderpacks del modpack
========================
  1. Complementary ReBorn v4.3.1  (recomendado)
  2. Sildur's Enhanced Default

Activalos desde Ajustes > Video > Shaders.
