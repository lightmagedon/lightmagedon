====================================================================
  LIGHTMAGEDON  -  Modpack para Minecraft 1.19.2 (Fabric)
  version 1.0.0  -  PLACEHOLDER
====================================================================

  *** ESTE ARCHIVO ES UN PLACEHOLDER DE PRUEBA ***
  *** Todavia no contiene los mods reales.        ***

--------------------------------------------------------------------
  1. REQUISITOS
--------------------------------------------------------------------
  - Minecraft Java Edition 1.19.2
  - Fabric Loader 0.14.21 o superior
  - Java 17 (OpenJDK 17)
  - RAM recomendada: 8 GB

--------------------------------------------------------------------
  2. INSTALACION (METODO RAPIDO)
--------------------------------------------------------------------
  1) Abre el lanzador y selecciona "Fabric" como version.
  2) Copia el contenido de esta carpeta dentro de .minecraft
  3) Copia mods/, config/, defaultconfigs/, resourcepacks/ y
     shaderpacks/ a la carpeta .minecraft correspondiente.
  4) Borra la carpeta mods/ que ya tenias para evitar conflictos.
  5) Listo. A jugar.

--------------------------------------------------------------------
  3. INSTALACION (FABRIC ADAPTADO)
--------------------------------------------------------------------
  Copia la carpeta mods/ a tu perfil de Fabric y deja que el
  launcher resuelva las dependencias automaticamente.

--------------------------------------------------------------------
  4. CONFIGURACION DE RAM
--------------------------------------------------------------------
  Edita "instalar/lanzamiento.bat" y ajusta la variable RAM.
  Recomendado: 8G si tienes 16 GB o mas de RAM.

--------------------------------------------------------------------
  5. CREDITS
--------------------------------------------------------------------
  Este modpack no esta afiliado a Mojang ni a Microsoft.
  Cada mod mantiene su propia licencia y creditos.

====================================================================
